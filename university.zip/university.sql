-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2024 at 06:25 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `department__1_`
--

CREATE TABLE `department__1_` (
  `COL 1` varchar(10) DEFAULT NULL,
  `COL 2` varchar(8) DEFAULT NULL,
  `COL 3` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department__1_`
--

INSERT INTO `department__1_` (`COL 1`, `COL 2`, `COL 3`) VALUES
('dept_name', 'building', 'budget'),
('Biology', 'Watson', '90000'),
('Comp. Sci.', 'Taylor', '100000'),
('Elec. Eng.', 'Taylor', '85000'),
('Finance', 'Painter', '120000'),
('History', 'Painter', '50000'),
('Music', 'Packard', '80000'),
('Physics', 'Watson', '70000');

-- --------------------------------------------------------

--
-- Table structure for table `instructor__3_`
--

CREATE TABLE `instructor__3_` (
  `COL 1` varchar(5) DEFAULT NULL,
  `COL 2` varchar(10) DEFAULT NULL,
  `COL 3` varchar(10) DEFAULT NULL,
  `COL 4` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `instructor__3_`
--

INSERT INTO `instructor__3_` (`COL 1`, `COL 2`, `COL 3`, `COL 4`) VALUES
('Id', 'Name', 'Dept_name', 'Salary'),
('10101', 'Srinivasan', 'Comp. sci.', '65000'),
('12121', 'Wu', 'Finance', '90000'),
('15151', 'Mozart', 'Music', '40000'),
('22222', 'Einstein', 'Physics', '95000'),
('32343', 'El Said', 'History', '60000'),
('33456', 'Gold', 'Physics', '87000'),
('45565', 'Katz', 'Comp. sci.', '75000'),
('58583', 'Califieri', 'History', '62000'),
('76543', 'Singh', 'Finance', '80000'),
('76766', 'Crick', 'Biology', '72000'),
('83821', 'Brandt', 'Comp. sci.', '92000'),
('98345', 'Kim', 'Elce. Eng.', '80000');

-- --------------------------------------------------------

--
-- Table structure for table `prereq`
--

CREATE TABLE `prereq` (
  `course_id` varchar(9) DEFAULT NULL,
  `prereq_id` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prereq`
--

INSERT INTO `prereq` (`course_id`, `prereq_id`) VALUES
('course_id', 'prereq_id'),
('BIO-301', 'BIO-101'),
('BIO-399', 'BIO-101'),
('CS-190', 'CS-101'),
('CS-315', 'CS-101'),
('CS-319', 'CS-101'),
('CS-347', 'CS-101'),
('EE-181', 'PHY-101');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `Course_id` varchar(9) DEFAULT NULL,
  `sec_id` varchar(6) DEFAULT NULL,
  `semester` varchar(8) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `building` varchar(9) DEFAULT NULL,
  `room_no` varchar(7) DEFAULT NULL,
  `time_slot_id` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`Course_id`, `sec_id`, `semester`, `year`, `building`, `room_no`, `time_slot_id`) VALUES
('Course_id', 'sec_id', 'semester', 'year', 'building', 'room_no', 'time_slot_id'),
('BIO-101', '1 ', 'Summer ', '2009 ', 'Painter ', '514 ', 'B'),
('BIO-301 ', '1 ', 'Summer ', '2010 ', 'Painter ', '514 ', 'A'),
('CS-101 ', '1 ', 'Fall ', '2009', 'Packard ', '101 ', 'H'),
('CS-101 ', '1 ', 'Spring ', '2010', ' Packard ', '101', ' F'),
('CS-190 ', '1 ', 'Spring ', '2009 ', 'Taylor ', '3128 ', 'E'),
('CS-190 ', '2 ', 'Spring ', '2009 ', 'Taylor ', '3128 ', 'A'),
('CS-315 ', '1 ', 'Spring ', '2010 ', 'Watson ', '120', ' D'),
('CS-319 ', '1 ', 'Spring ', '2010 ', 'Watson ', '100', ' B'),
('CS-319 ', '2 ', 'Spring ', '2010 ', 'Taylor ', '3128', ' C'),
('CS-347 ', '1 ', 'Fall ', '2009 ', 'Taylor', ' 3128', ' A'),
('EE-181 ', '1 ', 'Spring ', '2009 ', 'Taylor ', '3128 ', 'C'),
('FIN-201 ', '1 ', 'Spring ', '2010 ', 'Packard ', '101 ', 'B'),
('HIS-351 ', '1 ', 'Spring ', '2010 ', 'Painter ', '514 ', 'C'),
('MU-199 ', '1 ', 'Spring ', '2010 ', 'Packard', ' 101', ' D'),
('PHY-101', ' 1 ', 'Fall ', '2009 ', 'Watson ', '100 ', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `stduent`
--

CREATE TABLE `stduent` (
  `id` varchar(6) DEFAULT NULL,
  `name` varchar(8) DEFAULT NULL,
  `dept_name` varchar(11) DEFAULT NULL,
  `tot_credit` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stduent`
--

INSERT INTO `stduent` (`id`, `name`, `dept_name`, `tot_credit`) VALUES
('id', 'name', 'dept_name', 'tot_credit'),
('00128', 'Zhang ', 'Comp. Sci. ', '102'),
('12345 ', 'Shankar ', 'Comp. Sci. ', '32'),
('19991 ', 'Brandt ', 'History ', '80'),
('23121 ', 'Chavez ', 'Finance ', '110'),
('44553 ', 'Peltier ', 'Physics ', '56'),
('45678 ', 'Levy ', 'Physics ', '46'),
('00128', 'Zhang ', 'Comp. Sci. ', '102'),
('12345 ', 'Shankar ', 'Comp. Sci. ', '32'),
('19991 ', 'Brandt ', 'History ', '80'),
('23121 ', 'Chavez ', 'Finance ', '110'),
('44553 ', 'Peltier ', 'Physics ', '56'),
('45678 ', 'Levy ', 'Physics ', '46');

-- --------------------------------------------------------

--
-- Table structure for table `takes`
--

CREATE TABLE `takes` (
  `ID` varchar(5) DEFAULT NULL,
  `course_id` varchar(9) DEFAULT NULL,
  `sec_id` varchar(6) DEFAULT NULL,
  `semester` varchar(8) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `grade` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `takes`
--

INSERT INTO `takes` (`ID`, `course_id`, `sec_id`, `semester`, `year`, `grade`) VALUES
('ID', 'course_id', 'sec_id', 'semester', 'year', 'grade'),
('128', 'CS-101', '1', 'Fall', '2009', 'A'),
('128', 'CS-347', '1', 'Fall', '2009', 'A-'),
('12345', 'CS-101', '1', 'Fall', '2009', 'C'),
('12345', 'CS-190', '2', 'Spring', '2009', 'A'),
('12345', 'CS-315', '1', 'Spring', '2010', 'A'),
('12345', 'CS-347', '1', 'Fall', '2009', 'A'),
('19991', 'HIS-351', '1', 'Spring', '2010', 'B'),
('23121', 'FIN-201', '1', 'Spring', '2010', 'C+'),
('44553', 'PHY-101', '1', 'Fall', '2009', 'B-'),
('45678', 'CS-101', '1', 'Fall', '2009', 'F'),
('45678', 'CS-101', '1', 'Spring', '2010', 'B+'),
('45678', 'CS-319', '1', 'Spring', '2010', 'B'),
('54321', 'CS-101', '1', 'Fall', '2009', 'A-'),
('54321', 'CS-190', '2', 'Spring', '2009', 'B+'),
('55739', 'MU-199', '1', 'Spring', '2010', 'A-'),
('76543', 'CS-101', '1', 'Fall', '2009', 'A'),
('76543', 'CS-319', '2', 'Spring', '2010', 'A'),
('76653', 'EE-181', '1', 'Spring', '2009', 'C'),
('98765', 'CS-101', '1', 'Fall', '2009', 'C-'),
('98765', 'CS-315', '1', 'Spring', '2010', 'B'),
('98988', 'BIO-101', '1', 'Summer', '2009', 'A'),
('98988', 'BIO-301', '1', 'Summer', '2010', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `id` varchar(5) DEFAULT NULL,
  `course_id` varchar(9) DEFAULT NULL,
  `ses_id` varchar(6) DEFAULT NULL,
  `semister` varchar(8) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`id`, `course_id`, `ses_id`, `semister`, `year`) VALUES
('id', 'course_id', 'ses_id', 'semister', 'year'),
('10101', 'CS-101', '1', 'Fall', '2009'),
('10102', 'CS-315', '1', 'Spring', '2010'),
('10103', 'CS-347', '1', 'Fall', '2009'),
('12121', 'FIN-201', '1', 'Spring', '2010'),
('15151', 'MU-199', '1', 'Spring', '2010'),
('22222', 'PHY-101', '1', 'FALL', '2009'),
('32342', 'HIS-351', '1', 'Spring', '2010'),
('45565', 'CS-101', '1', 'Spring', '2010'),
('45565', 'CS-319', '1', 'Spring', '2010'),
('76766', 'BIO-101', '1', 'Summer', '2009'),
('76766', 'BIO-301', '1', 'Summer', '2010'),
('83821', 'CS-190', '1', 'Spring', '2009'),
('83821', 'CS-190', '2', 'Spring', '2009'),
('83821', 'CS-319', '2', 'Spring', '2010'),
('98345', 'EE-181', '1', 'Spring', '2009');

-- --------------------------------------------------------

--
-- Table structure for table `time_slot`
--

CREATE TABLE `time_slot` (
  `time slot id` varchar(12) DEFAULT NULL,
  `day` varchar(3) DEFAULT NULL,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_slot`
--

INSERT INTO `time_slot` (`time slot id`, `day`, `start_time`, `end_time`) VALUES
('time slot id', 'day', 'start_time', 'end_time'),
('A', 'M', '8:00', '8:50'),
('A', 'W', '8:00', '8:50'),
('A', 'F', '8:00', '8:50'),
('B', 'M', '9:00', '9:50'),
('B', 'W', '9:00', '9:50'),
('B', 'F', '9:00', '9:50'),
('C', 'M', '11:00', '11:50'),
('C', 'W', '11:00', '11:50'),
('C', 'F', '11:00', '11:50'),
('D', 'M', '13:00', '13:50'),
('D', 'W', '13:00', '13:50'),
('D', 'F', '13:00', '13:50'),
('E', 'T', '10:30', '13:50'),
('E', 'R', '10:30', '13:50'),
('F', 'T', '14:30', '14:50'),
('F', 'R', '14:30', '15:45'),
('G', 'M', '16:00', '16:50'),
('G', 'W', '16:00', '16:50'),
('G', 'F', '16:00', '16:50'),
('H', 'W', '10:00', '12:30');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
